# Ticketradar Ubuntu 部署包

## 📋 包含文件
- 核心程序: main.py, models.py
- 配置文件: requirements.txt, .env.example
- 安装脚本: ubuntu_install.sh, install_deps.py
- Web界面: templates/, static/
- 文档: *.md

## 🚀 部署步骤

### 1. 上传到服务器
```bash
# 解压部署包
unzip ticketradar-ubuntu-deploy.zip
cd ticketradar-deploy
```

### 2. 一键安装
```bash
chmod +x ubuntu_install.sh
./ubuntu_install.sh
```

### 3. 启动系统
```bash
./start_background.sh
```

### 4. 访问系统
http://your-server-ip:38181

## 🔧 配置
编辑 .env 文件配置PushPlus等参数

## 📞 技术支持
微信: Xinx--1996
